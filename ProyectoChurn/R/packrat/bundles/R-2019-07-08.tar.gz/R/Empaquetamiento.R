library(packrat)

init() # inicalizamos packrat para nuestro proyecto.

packrat::bundle() # nuestro directorio de trabajo es nuestro proyecto.
