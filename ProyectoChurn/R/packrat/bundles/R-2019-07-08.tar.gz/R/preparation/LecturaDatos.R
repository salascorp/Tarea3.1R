Datos_Churn <- read.csv("D:/perfil/Desktop/69_Curso Avanzado R - PROMIDAT/2_Clase 2/2_Tarea/1_Insumos/Datos_Churn_train.csv")

write.csv(Datos_Churn, "data/Datos_Churn.csv")



