library(usethis)

use_directory("R")
use_directory("R/preparation")
use_directory("R/processing")
use_directory("R/modeling")
use_directory("test")
use_directory("data")
use_directory("reports")




